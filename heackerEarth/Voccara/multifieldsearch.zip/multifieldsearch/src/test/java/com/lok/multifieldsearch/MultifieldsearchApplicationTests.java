package com.lok.multifieldsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultifieldsearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
