package com.lok.multifieldsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultifieldsearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultifieldsearchApplication.class, args);
	}

}
